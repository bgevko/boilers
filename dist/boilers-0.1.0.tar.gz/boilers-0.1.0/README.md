# Boiler
A super lightweight, general purpose boilerplate fetcher. If my templates are too opinionated, make a fork and have at it!

### Usage
```bash
boiler <template> # Use one of the commmands below
```

### Available templates
- `html`
- `c`
- `cmake-cpp`

