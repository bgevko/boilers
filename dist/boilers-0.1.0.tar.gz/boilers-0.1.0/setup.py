from setuptools import setup, find_packages

setup(
    name='boilers',
    version='0.1.0',
    description='Boilerplate templates for various languages and frameworks',
    author='Bogdan Gevko',
    install_requires=[
        'certifi==2023.7.22',
        'charset-normalizer==3.2.0',
        'idna==3.4',
        'Pygments==2.16.0',
        'requests==2.31.0',
        'rich==13.5.2',
    ],
    entry_points={
        'console_scripts': [
            'boilers = boilers.__main__:main'
        ]
    },
)
